import React, { useState } from 'react';

interface CostInputs {
  waxPrice: string;
  waxAmount: string;
  fragrancePrice: string;
  fragranceAmount: string;
  wickPrice: string;
  wickCount: string;
  containerPrice: string;
  lidPrice: string;
  dyePrice: string;
  dyeAmount: string;
  decorPrice: string;
  additionalCosts: string;
  packagingCosts: string;
  marketingCosts: string;
  laborCosts: string;
  monthlyCandles: string;
}

const CostCalculator = () => {
  const [inputs, setInputs] = useState<CostInputs>({
    waxPrice: '',
    waxAmount: '',
    fragrancePrice: '',
    fragranceAmount: '',
    wickPrice: '',
    wickCount: '',
    containerPrice: '',
    lidPrice: '',
    dyePrice: '',
    dyeAmount: '',
    decorPrice: '',
    additionalCosts: '',
    packagingCosts: '',
    marketingCosts: '',
    laborCosts: '',
    monthlyCandles: '',
  });

  const handleInputChange = (field: keyof CostInputs) => (
    e: React.ChangeEvent<HTMLInputElement>
  ) => {
    setInputs((prev) => ({
      ...prev,
      [field]: e.target.value,
    }));
  };

  const calculateCosts = () => {
    let totalCost = 0;

    // Wax cost
    if (inputs.waxPrice && inputs.waxAmount) {
      totalCost += (parseFloat(inputs.waxPrice) / 1000) * parseFloat(inputs.waxAmount);
    }

    // Fragrance cost
    if (inputs.fragrancePrice && inputs.fragranceAmount) {
      totalCost += parseFloat(inputs.fragrancePrice) * parseFloat(inputs.fragranceAmount);
    }

    // Wick cost
    if (inputs.wickPrice && inputs.wickCount) {
      totalCost += parseFloat(inputs.wickPrice) * parseFloat(inputs.wickCount);
    }

    // Container cost
    if (inputs.containerPrice) {
      totalCost += parseFloat(inputs.containerPrice);
    }
    if (inputs.lidPrice) {
      totalCost += parseFloat(inputs.lidPrice);
    }

    // Dye cost
    if (inputs.dyePrice && inputs.dyeAmount) {
      totalCost += parseFloat(inputs.dyePrice) * parseFloat(inputs.dyeAmount);
    }

    // Additional costs
    if (inputs.decorPrice) totalCost += parseFloat(inputs.decorPrice);
    if (inputs.additionalCosts) totalCost += parseFloat(inputs.additionalCosts);
    if (inputs.packagingCosts) totalCost += parseFloat(inputs.packagingCosts);

    // Marketing and labor costs per candle
    if (inputs.marketingCosts && inputs.monthlyCandles) {
      totalCost += parseFloat(inputs.marketingCosts) / parseFloat(inputs.monthlyCandles);
    }
    if (inputs.laborCosts && inputs.monthlyCandles) {
      totalCost += parseFloat(inputs.laborCosts) / parseFloat(inputs.monthlyCandles);
    }

    return totalCost;
  };

  const totalCost = calculateCosts();

  const renderInput = (
    label: string,
    field: keyof CostInputs,
    placeholder: string,
    unit: string
  ) => (
    <div>
      <label className="block text-sm font-medium text-gray-700 mb-2">{label}</label>
      <div className="relative">
        <input
          type="number"
          value={inputs[field]}
          onChange={handleInputChange(field)}
          className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
          placeholder={placeholder}
        />
        <span className="absolute right-3 top-2.5 text-gray-500 text-sm">{unit}</span>
      </div>
    </div>
  );

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-6">
          {renderInput('Стоимость воска за 1 кг', 'waxPrice', '0', 'руб')}
          {renderInput('Необходимое количество воска для свечи', 'waxAmount', '0', 'гр')}
          {renderInput('Стоимость отдушки за 1 гр', 'fragrancePrice', '0', 'руб')}
          {renderInput('Количество отдушки на свечу', 'fragranceAmount', '0', 'гр')}
          {renderInput('Стоимость фитиля', 'wickPrice', '0', 'руб')}
          {renderInput('Количество фитилей для свечи', 'wickCount', '0', 'шт')}
          {renderInput('Стоимость контейнера', 'containerPrice', '0', 'руб')}
          {renderInput('Стоимость крышки для контейнера', 'lidPrice', '0', 'руб')}
        </div>
        <div className="space-y-6">
          {renderInput('Стоимость красителя за 1гр', 'dyePrice', '0', 'руб')}
          {renderInput('Количество красителя', 'dyeAmount', '0', 'гр')}
          {renderInput('Расходы на декор', 'decorPrice', '0', 'руб')}
          {renderInput('Дополнительные расходы', 'additionalCosts', '0', 'руб')}
          {renderInput('Расходы на упаковку', 'packagingCosts', '0', 'руб')}
          {renderInput('Расходы на маркетинг за 1 мес', 'marketingCosts', '0', 'руб')}
          {renderInput('Цена времени на изготовление', 'laborCosts', '0', 'руб')}
          {renderInput('Количество свечей в месяц', 'monthlyCandles', '0', 'шт')}
        </div>
      </div>

      <div className="mt-8 p-6 bg-indigo-50 rounded-lg">
        <div className="text-center">
          <div className="text-lg text-gray-600 mb-2">Себестоимость одной свечи</div>
          <div className="text-3xl font-bold text-indigo-600">
            {totalCost.toFixed(2)} руб
          </div>
        </div>
      </div>
    </div>
  );
};

export default CostCalculator;