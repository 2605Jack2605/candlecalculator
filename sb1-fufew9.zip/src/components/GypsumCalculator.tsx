import React, { useState } from 'react';
import { Info } from 'lucide-react';

type GypsumType = 'g16' | 'sculptor' | 'friplast';

const GypsumCalculator = () => {
  const [gypsumType, setGypsumType] = useState<GypsumType>('g16');
  const [waterVolume, setWaterVolume] = useState<string>('');
  const [useSVV, setUseSVV] = useState(false);
  const [useTitanium, setUseTitanium] = useState(false);

  const calculateResults = () => {
    const volume = parseFloat(waterVolume) || 0;
    let results = { gypsum: 0, water: 0, svv: 0, titanium: 0 };

    switch (gypsumType) {
      case 'g16':
        if (useSVV) {
          results.gypsum = volume * 1.33;
          results.water = volume * 0.293;
          results.svv = results.gypsum * 0.04;
        } else {
          results.gypsum = volume * 1.2;
          results.water = volume * 0.48;
        }
        if (useTitanium) {
          results.titanium = results.gypsum * 0.05;
        }
        break;
      case 'sculptor':
        results.gypsum = volume * 1.64;
        results.water = volume * 0.41;
        if (useTitanium) {
          results.titanium = results.gypsum * 0.05;
        }
        break;
      case 'friplast':
        results.gypsum = volume * 1.673;
        results.water = volume * 0.418;
        break;
    }

    return results;
  };

  const results = calculateResults();

  return (
    <div className="space-y-6">
      <div className="flex items-start gap-4 bg-blue-50 p-4 rounded-lg">
        <Info className="w-5 h-5 text-blue-600 mt-1 flex-shrink-0" />
        <p className="text-sm text-blue-700">
          Наполните пустой контейнер водой до уровня, представляющего желаемый объем формы
        </p>
      </div>

      <div className="grid gap-6">
        <div className="space-y-4">
          <label className="block text-sm font-medium text-gray-700">Тип гипса</label>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            {[
              { id: 'g16', label: 'Гипс Г16' },
              { id: 'sculptor', label: 'Скульптор' },
              { id: 'friplast', label: 'Фрипласт аква' },
            ].map((type) => (
              <button
                key={type.id}
                onClick={() => setGypsumType(type.id as GypsumType)}
                className={`px-4 py-2 rounded-lg border ${
                  gypsumType === type.id
                    ? 'bg-indigo-600 text-white border-indigo-600'
                    : 'bg-white text-gray-700 border-gray-300 hover:bg-gray-50'
                }`}
              >
                {type.label}
              </button>
            ))}
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Объем воды в форме, мл
          </label>
          <input
            type="number"
            value={waterVolume}
            onChange={(e) => setWaterVolume(e.target.value)}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
            placeholder="Введите объем воды"
          />
        </div>

        {gypsumType === 'g16' && (
          <div className="flex flex-col sm:flex-row gap-4">
            <label className="flex items-center space-x-2">
              <input
                type="checkbox"
                checked={useSVV}
                onChange={(e) => setUseSVV(e.target.checked)}
                className="w-4 h-4 text-indigo-600 rounded focus:ring-indigo-500"
              />
              <span className="text-sm text-gray-700">СВВ-500</span>
            </label>
            <label className="flex items-center space-x-2">
              <input
                type="checkbox"
                checked={useTitanium}
                onChange={(e) => setUseTitanium(e.target.checked)}
                className="w-4 h-4 text-indigo-600 rounded focus:ring-indigo-500"
              />
              <span className="text-sm text-gray-700">Диоксид титана</span>
            </label>
          </div>
        )}

        {gypsumType === 'sculptor' && (
          <label className="flex items-center space-x-2">
            <input
              type="checkbox"
              checked={useTitanium}
              onChange={(e) => setUseTitanium(e.target.checked)}
              className="w-4 h-4 text-indigo-600 rounded focus:ring-indigo-500"
            />
            <span className="text-sm text-gray-700">Диоксид титана</span>
          </label>
        )}

        {waterVolume && (
          <div className="grid gap-4 p-6 bg-gray-50 rounded-lg">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              <div className="bg-white p-4 rounded-lg shadow-sm">
                <div className="text-sm text-gray-500 mb-1">Количество гипса</div>
                <div className="text-lg font-semibold">{results.gypsum.toFixed(1)} гр</div>
              </div>
              <div className="bg-white p-4 rounded-lg shadow-sm">
                <div className="text-sm text-gray-500 mb-1">Количество воды</div>
                <div className="text-lg font-semibold">{results.water.toFixed(1)} мл</div>
              </div>
              {results.svv > 0 && (
                <div className="bg-white p-4 rounded-lg shadow-sm">
                  <div className="text-sm text-gray-500 mb-1">Количество СВВ-500</div>
                  <div className="text-lg font-semibold">{results.svv.toFixed(1)} гр</div>
                </div>
              )}
              {results.titanium > 0 && (
                <div className="bg-white p-4 rounded-lg shadow-sm">
                  <div className="text-sm text-gray-500 mb-1">Диоксид титана</div>
                  <div className="text-lg font-semibold">{results.titanium.toFixed(1)} гр</div>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default GypsumCalculator;