import React, { useState } from 'react';
import { Info } from 'lucide-react';

const CandleCalculator = () => {
  const [waterVolume, setWaterVolume] = useState<string>('');
  const [fragrance, setFragrance] = useState<string>('');
  const [candleCount, setCandleCount] = useState<string>('');

  const calculateResults = () => {
    const volume = parseFloat(waterVolume) || 0;
    const fragrancePercent = parseFloat(fragrance) || 0;
    const count = parseInt(candleCount) || 0;

    const totalWeight = volume * 0.9 * count;
    const fragranceWeight = (volume * 0.9 * (fragrancePercent / 100)) * count;
    const waxWeight = (volume * 0.9 - fragranceWeight / count) * count;

    return {
      totalWeight,
      waxWeight,
      fragranceWeight,
    };
  };

  const results = calculateResults();

  return (
    <div className="space-y-6">
      <div className="flex items-start gap-4 bg-blue-50 p-4 rounded-lg">
        <Info className="w-5 h-5 text-blue-600 mt-1 flex-shrink-0" />
        <p className="text-sm text-blue-700">
          Наполните пустой контейнер водой до уровня, представляющего желаемый объем воска и запишите вес воды
        </p>
      </div>

      <div className="grid gap-6">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Объем воды в контейнере, мл
          </label>
          <input
            type="number"
            value={waterVolume}
            onChange={(e) => setWaterVolume(e.target.value)}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
            placeholder="Введите объем воды"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Концентрация ароматической отдушки, %
          </label>
          <input
            type="number"
            value={fragrance}
            onChange={(e) => setFragrance(e.target.value)}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
            placeholder="Введите концентрацию"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Количество свечей, шт
          </label>
          <input
            type="number"
            value={candleCount}
            onChange={(e) => setCandleCount(e.target.value)}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
            placeholder="Введите количество свечей"
          />
        </div>

        {waterVolume && fragrance && candleCount && (
          <div className="grid gap-4 p-6 bg-gray-50 rounded-lg">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="bg-white p-4 rounded-lg shadow-sm">
                <div className="text-sm text-gray-500 mb-1">Общий вес (воск + отдушка)</div>
                <div className="text-lg font-semibold">{results.totalWeight.toFixed(1)} гр</div>
              </div>
              <div className="bg-white p-4 rounded-lg shadow-sm">
                <div className="text-sm text-gray-500 mb-1">Количество воска</div>
                <div className="text-lg font-semibold">{results.waxWeight.toFixed(1)} гр</div>
              </div>
              <div className="bg-white p-4 rounded-lg shadow-sm">
                <div className="text-sm text-gray-500 mb-1">Количество отдушки</div>
                <div className="text-lg font-semibold">{results.fragranceWeight.toFixed(1)} гр</div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default CandleCalculator;