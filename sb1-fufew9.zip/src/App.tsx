import React, { useState } from 'react';
import { Calculator, Flame, DollarSign } from 'lucide-react';
import GypsumCalculator from './components/GypsumCalculator';
import CandleCalculator from './components/CandleCalculator';
import CostCalculator from './components/CostCalculator';

function App() {
  const [activeTab, setActiveTab] = useState('gypsum');

  const tabs = [
    { id: 'gypsum', name: 'Расчет гипса', icon: Calculator },
    { id: 'candle', name: 'Расчет воска', icon: Flame },
    { id: 'cost', name: 'Себестоимость', icon: DollarSign },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-indigo-50">
      <div className="max-w-4xl mx-auto p-4">
        <h1 className="text-3xl font-bold text-center text-gray-800 mb-8 pt-4">
          Калькулятор свечевара / гипсодела
        </h1>

        <div className="bg-white rounded-xl shadow-lg overflow-hidden mb-8">
          <div className="flex overflow-x-auto border-b">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center px-6 py-4 text-sm font-medium transition-colors duration-200 ${
                  activeTab === tab.id
                    ? 'bg-indigo-50 text-indigo-600 border-b-2 border-indigo-600'
                    : 'text-gray-600 hover:text-gray-900 hover:bg-gray-50'
                }`}
              >
                <tab.icon className="w-5 h-5 mr-2" />
                {tab.name}
              </button>
            ))}
          </div>

          <div className="p-6">
            {activeTab === 'gypsum' && <GypsumCalculator />}
            {activeTab === 'candle' && <CandleCalculator />}
            {activeTab === 'cost' && <CostCalculator />}
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;